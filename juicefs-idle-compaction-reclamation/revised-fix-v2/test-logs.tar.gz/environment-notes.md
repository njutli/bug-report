# Verification environment notes

- Source base: JuiceFS v1.4.1, commit 0b90c7db5a929ae6adc5faad948d108efd2c99f9.
- Toolchain: go1.26.0 linux/amd64.
- The first VFS race build failed with `no space left on device` in `/tmp/opencode/go-build...`, before tests ran. `/tmp` is a 7.7 GiB tmpfs; after the failed build's cleanup it was still about 7.0 GiB used with 704 MiB available. The review workspace itself occupied about 101 MiB. Other temporary data was not removed.
- Retried with GOTMPDIR=/home/lilingfeng/tmp/juicefs-reclaim-v2-build (disk-backed), -p 1, full -race and unchanged test selection. Meta and VFS tests then completed successfully, each repeated three times.
- Initial CLI test exposed unsupported UintFlag classification; the candidate uses IntFlag and the CLI test and actual mount --help subsequently passed.
- SQL paging was improved after inspection: an OR predicate produced an SQLite index SCAN; tuple comparison now produces a composite-index SEARCH. Both range-plan and page-completeness tests passed with race three times.
- make test.meta.core ran in an isolated network namespace. TestRedisClient passed; TestLoadDump later stopped at unavailable isolated TiKV PD 127.0.0.1:2379.
- make test.pkg was blocked by unavailable offline gogfapi dependency and a pre-existing root-inode expectation incompatible with the container filesystem. make test.cmd could not launch its test command because sudo was absent.
- The final generic development build command completed with exit status 0. The binary reports 1.4.1+unknown. It is not a production release or a Ceph-enabled deployment validation.
